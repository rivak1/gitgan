function validateData() {   
    alert("welcome to Meta-parking")
    var formValue = document.getElementById("inputdata").value;
}